package Teste_Unitario;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import classes.Comprador;
import java.time.LocalDate;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 2142153512
 */
public class TestComprador {
    
    @Test
    public void criandoObjeto(){
        
        Comprador comprador = new Comprador();
        
        comprador.setCidade("null");
        comprador.setCpf("null");
        comprador.setEstado("null");
        comprador.setNome("null");
        comprador.setSexo("null");
        comprador.setDataNascimento(LocalDate.now());
        
        assertEquals(LocalDate.now(), comprador.getDataNascimento());
    }
}
