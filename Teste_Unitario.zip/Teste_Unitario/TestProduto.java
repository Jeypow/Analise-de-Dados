/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Teste_Unitario;

import classes.Produto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 2142153512
 */
public class TestProduto {
    
    public void criandoObjeto(){
        
        Produto produto = new Produto();
        produto.setNome("");
        produto.setMarca("");
        produto.setQuantidade();
        produto.setTamanho();
        produto.setGrupo("");
        produto.setValor("");
        
        assertEquals("", produto.getNome());
        
    }
    
//    private String nome; //Nome do produto
//    private String marca; //Marca do Produto
//    
//    private int tamanho; //Tamanho do produto 43 . 32 etc....
//    private int quantidade;
//    private int grupo;
//    
//    private double valor;
//    
//    private final int tipo = 3; //tipo de dados
}
